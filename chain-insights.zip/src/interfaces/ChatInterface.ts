export default interface ChatInterface{
    id: string,
    name: string,
    currency: string,
    last_activity_date: Date
}