<template>
  <div class="logo">
    <img src="@/assets/logo.png" width="30" alt="Chain Insights" />
  </div>
</template>

<script>
export default {
  name: "MainLogo",
};
</script>

<style scoped>
.logo img {
  height: 1.875rem;
  width: auto;
}
</style>
